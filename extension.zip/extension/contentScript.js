
// Listen for changes in the Meet page's DOM
document.addEventListener('DOMContentLoaded', function () {
    // logic to extract participant name
    
    const participantNameElement = document.querySelector('.participant-name');
    if (participantNameElement) {
        const participantName = participantNameElement.innerText;
        // Send participant name to background script or popup.html for further processing/display
        chrome.runtime.sendMessage({ participantName: participantName });
    }
});
